﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos.DTO
{
    public class PersonaDTO
    {
        public int Id { get; set; }
        public Nullable<int> TipoIdentificacionId { get; set; }
        public string NumeroIdentificacion { get; set; }
        public string Nombre { get; set; }
        public Nullable<bool> Estado { get; set; }
        
    }
}
