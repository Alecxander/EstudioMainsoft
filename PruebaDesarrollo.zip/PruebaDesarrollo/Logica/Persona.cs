﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Datos;
using Datos.DTO;

namespace Logica
{
    public class Persona
    {
        public static List<PersonaDTO> ObtenerPersonas()
        {
            DataTable personasDatatable = new DataTable();
            using (Soporte_SISEEntities db = new Soporte_SISEEntities())
            {
                var personas = db.ObtenerTodasPersonasSP().Select(p => new PersonaDTO {
                    Id = p.Id,
                    Estado = p.Estado,
                    Nombre = p.Nombre,
                    NumeroIdentificacion = p.NumeroIdentificacion,
                    TipoIdentificacionId = p.TipoIdentificacionId
                }).ToList();

              

                return personas;
            }

        }

        public static PersonaDTO ObtenerPersonaPorId(int? id)
        {
            DataTable personasDatatable = new DataTable();
            using (Soporte_SISEEntities db = new Soporte_SISEEntities())
            {
                var persona = db.ObtenerPersonaPorIdSP(id).Select(p => new PersonaDTO
                {
                    Id = p.Id,
                    Estado = p.Estado,
                    Nombre = p.Nombre,
                    NumeroIdentificacion = p.NumeroIdentificacion,
                    TipoIdentificacionId = p.TipoIdentificacionId
                }).FirstOrDefault();

                return persona;
            }

        }


        public static Boolean numeroCorrecto(String nombre)
        {
            String expresion;
            expresion = "[0-9]";
            nombre = nombre.Replace(" ", "");
            if (Regex.IsMatch(nombre, expresion))
            {
                if (Regex.Replace(nombre, expresion, String.Empty).Length == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public static Boolean nitCorrecto(String nombre)
        {
            String expresion;
            expresion = "[0-9a-zA-ZñÑ]";
            nombre = nombre.Replace(" ", "");
            if (Regex.IsMatch(nombre, expresion))
            {
                if (Regex.Replace(nombre, expresion, String.Empty).Length == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public static Boolean nombreCorrecto(String nombre)
        {
            String expresion;
            expresion = "[a-zA-ZñÑ]";
            nombre = nombre.Replace(" ", "");
            if (Regex.IsMatch(nombre, expresion))
            {
                if (Regex.Replace(nombre, expresion, String.Empty).Length == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public static string ModificarPersona (int id, string tipoIdentificacionId, string numeroIdentificacion, string nombre, bool estado)
        {
            var _tipoIdentificacionId = Int32.Parse(tipoIdentificacionId);

            if (nombre.Length <= 30)
            {
                if (!nombreCorrecto(nombre))
                {
                    return "En nombre solo debe tener caractere alfabeticos con espacios.";
                }
            }
            else
            {
                return "El nombre debe tener maximo 30 caracteres.";
            }

            if (numeroIdentificacion.Trim().Length < 20)
            {
                if (_tipoIdentificacionId != 3)
                {
                    if (!numeroCorrecto(numeroIdentificacion))
                    {
                        return "Solo se permiten números para este tipo de identificación";
                    }
                }
                else
                {
                    if (!nitCorrecto(numeroIdentificacion))
                    {
                        return "Solo se permiten caracteres alfanumericos para este tipo de identificación";
                    }
                }
            }
            else
            {
                return "La longitud de los caracteres debe ser menor o igual a 20";
            }



            using (Soporte_SISEEntities db = new Soporte_SISEEntities())
            {
                var persona = db.Personas.FirstOrDefault(p => p.Id == id);
                persona.TipoIdentificacionId = _tipoIdentificacionId;
                persona.Estado = estado;
                persona.Nombre = nombre;
                persona.NumeroIdentificacion = numeroIdentificacion;
                db.SaveChanges();
                return "ok";
            }
        }

        public static string CrearPersona(string tipoIdentificacionId, string numeroIdentificacion, string nombre, bool estado)
        {

            var _tipoIdentificacionId = Int32.Parse(tipoIdentificacionId);

            if (nombre.Length <= 30)
            {
                if (!nombreCorrecto(nombre))
                {
                    return "En nombre solo debe tener caractere alfabeticos con espacios.";
                }
            }
            else
            {
                return "El nombre debe tener maximo 30 caracteres.";
            }
            if (numeroIdentificacion.Trim().Length < 20)
            {
                if (_tipoIdentificacionId != 3)
                {
                    if (!numeroCorrecto(numeroIdentificacion))
                    {
                        return "Solo se permiten números para este tipo de identificación";
                    }
                }
                else
                {
                    if (!nitCorrecto(numeroIdentificacion))
                    {
                        return "Solo se permiten caracteres alfanumericos para este tipo de identificación";
                    }
                }
            }
            else
            {
                return "La longitud de los caracteres debe ser menor o igual a 20";
            }


            using (Soporte_SISEEntities db = new Soporte_SISEEntities())
            {
                var persona = new Datos.Persona()
                {
                    TipoIdentificacionId = _tipoIdentificacionId,
                    Estado = estado,
                    Nombre = nombre,
                    NumeroIdentificacion = numeroIdentificacion
                };

                db.Personas.Add(persona);
                db.SaveChanges();
                return "ok";
            }
            //return string.Format("Persona: {0}, almacenada correctamete", nombre);

        }
    }
}
